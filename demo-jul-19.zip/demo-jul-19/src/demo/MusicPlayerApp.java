package demo;

public class MusicPlayerApp {
    public static void main(String[] args) {
        PlayList playList = new PlayList();
        playList.addSong(new Song("Song1", "artist1", 300));
        playList.addSong(new Song("Song2", "artist2", 350));
        playList.addSong(new Song("Song3", "artist3", 400));

        MusicPlayer musicPlayer = new MusicPlayer();
        musicPlayer.loadPlayList(playList);

        musicPlayer.play();
        musicPlayer.next();
        musicPlayer.pause();
        musicPlayer.play();
        musicPlayer.previous();
        musicPlayer.stop();
    }
}
