package demo;

public class PlayerControls {
    public void play(Song song) {
        System.out.println("Playing: " + song);
    }

    public void pause(Song song) {
        System.out.println("Paused: " + song);
    }

    public void stop() {
        System.out.println("Stopped");
    }

    public void next(PlayList playList, int currentIndex) {
        Song nextSong = playList.getSong(currentIndex + 1);
        if (nextSong != null) {
            play(nextSong);
        } else {
            System.out.println("End of playlist");
        }
    }

    public void previous(PlayList playList, int currentIndex) {
        Song prevSong = playList.getSong(currentIndex - 1);
        if (prevSong != null) {
            play(prevSong);
        } else {
            System.out.println("Start of playlist");
        }
    }
}
