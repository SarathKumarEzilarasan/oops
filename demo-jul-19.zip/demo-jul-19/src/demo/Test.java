package demo;


public class Test {
    public static void main(String[] args) {
        HashMap<String, Integer> map = new HashMap<>();
        map.put("one", 1);
        map.put("two", 2);
        map.put("three", 3);

        System.out.println(map.get("one"));
        System.out.println(map.containsKey("one"));
        System.out.println(map.containsValue(2));
        System.out.println(map.remove("one"));
        System.out.println(map.remove("two"));
        System.out.println(map.remove("three"));
        System.out.println(map.getSize());
        System.out.println(map.isEmpty());
    }
}
