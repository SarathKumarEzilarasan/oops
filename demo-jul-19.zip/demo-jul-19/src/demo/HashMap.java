package demo;

import java.util.Objects;

public class HashMap<K, V> {
    private int size;
    private Entry<K, V>[] buckets;
    private static final int DEFAULT_CAPACITY = 16;

    public HashMap() {
        this.buckets = new Entry[DEFAULT_CAPACITY];
        this.size = 0;
    }

    public int getSize() {
        return size;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    private int getHash(K key) {
        return Objects.hashCode(key);
    }

    public void put(K key, V value) {
        int bucketIndex = getHash(key) % buckets.length;
        Entry<K, V> newEntry = new Entry<>(key, value);

        if (buckets[bucketIndex] == null) {
            buckets[bucketIndex] = newEntry;
        } else {
            Entry<K, V> current = buckets[bucketIndex];
            while (current != null) {
                if (current.getKey().equals(key)) {
                    current.setValue(value);
                    return;
                }
                if (current.getNext() == null) {
                    current.setNext(newEntry);
                    break;
                }
                current = current.getNext();
            }
        }
        size++;
    }

    public V get(K key) {
        int bucketIndex = getHash(key) % buckets.length;
        Entry<K, V> entry = buckets[bucketIndex];

        while (entry != null) {
            if (entry.getKey().equals(key)) {
                return entry.getValue();
            }
            entry = entry.getNext();
        }
        return null;
    }

    public boolean containsKey(K key) {
        int bucketIndex = getHash(key) % buckets.length;
        Entry<K, V> entry = buckets[bucketIndex];
        while (entry != null) {
            if (entry.getKey().equals(key)) {
                return true;
            }
            entry = entry.getNext();
        }
        return false;
    }

    public boolean containsValue(V value) {
        for (Entry<K, V> bucket : buckets) {
            Entry<K, V> entry = bucket;
            while (entry != null) {
                if (bucket.getValue().equals(value)) {
                    return true;
                }
                entry = entry.getNext();
            }
        }
        return false;
    }

    public V remove(K key) {
        int bucketIndex = getHash(key) % buckets.length;
        Entry<K, V> previous = null;
        Entry<K, V> current = buckets[bucketIndex];

        while (current != null) {
            if (current.getKey().equals(key)) {
                if (previous == null) {
                    buckets[bucketIndex] = current.getNext();
                } else {
                    previous.setNext(current.getNext());
                }
                size--;
                return current.getValue();
            }
            previous = current;
            current = current.getNext();
        }
        return null;
    }
}


class Entry<K, V> {
    private K key;
    private V value;
    private Entry<K, V> next;

    public Entry(K key, V value) {
        this.key = key;
        this.value = value;
    }

    public K getKey() {
        return key;
    }

    public V getValue() {
        return value;
    }

    public void setValue(V value) {
        this.value = value;
    }

    public Entry<K, V> getNext() {
        return next;
    }

    public void setNext(Entry<K, V> next) {
        this.next = next;
    }
}