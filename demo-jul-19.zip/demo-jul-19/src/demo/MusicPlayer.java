package demo;

public class MusicPlayer {
    private PlayList playList;
    private PlayerControls playerControls;
    private int currentIndex;

    public MusicPlayer() {
        this.playList = new PlayList();
        this.playerControls = new PlayerControls();
        this.currentIndex = -1;
    }

    public void loadPlayList(PlayList playList) {
        this.playList = playList;
    }

    public void play() {
        if (currentIndex == -1 && !playList.getSongs().isEmpty()) {
            currentIndex = 0;
        }
        Song song = playList.getSong(currentIndex);
        if (song != null) {
            playerControls.play(song);
        }
    }


    public void pause() {
        if (currentIndex == -1 && !playList.getSongs().isEmpty()) {
            System.out.println("No song is playing.....");
            return;
        }
        Song song = playList.getSong(currentIndex);
        if (song != null) {
            playerControls.pause(song);
        }
    }

    public void stop() {
        if (currentIndex == -1 && !playList.getSongs().isEmpty()) {
            System.out.println("No song to stop.....");
            return;
        }
        playerControls.stop();
        currentIndex = -1;
    }

    public void next() {
        playerControls.next(playList, currentIndex);
        currentIndex++;
    }

    public void previous() {
        playerControls.previous(playList, currentIndex);
        currentIndex--;
    }
}
